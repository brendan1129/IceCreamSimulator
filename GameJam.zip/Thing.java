public class Thing {

   public int x, y;
   public int speed;
   
}