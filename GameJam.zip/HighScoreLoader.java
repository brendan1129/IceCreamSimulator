import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.OutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;

public class HighScoreLoader {
   GamePanel gp;
   public HighScoreLoader(GamePanel g) {
      this.gp = g;
   }
   public void saveScore() {

      try {
         ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("score.txt")));
         HighScore highScore = new HighScore();
         
      }
      catch ( Exception e ) {
         System.out.println("Save Exception" );
         e.printStackTrace();
      }
   }
   public String loadScore() {
      try{
         BufferedReader br = new BufferedReader(new FileReader("C:/Users/brend/Documents/Projects/GameJam/score.txt"));
         String line = br.readLine();
         return line;
      }
      catch (Exception e) {
         System.out.println("Load Exception");
         return "Error";
      }
   }
}