import java.io.Serializable;

public class HighScore implements Serializable {
   int hS;
}